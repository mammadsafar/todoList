module.exports = {
    mongodbUrl: 'mongodb://localhost:27017/todoList',
    secretKey: '/\/\0H@mm@|)'
}